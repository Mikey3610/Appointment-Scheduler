"# C195Project"

Application Purpose - This application allows users to login to an appointment scheduling system.
It allows the user to add, modify, or delete appointments with different parameters such as times, dates, names, contact info, among others.
It allows the user to add, modify, or delete customers with different parameters such as contact info among others.
It allows the user to view reports based on the appointments and customers saved in the application.

Author - Michael Skrzypczak
Contact - mskrzyp@my.wgu.edu
Application version - IntelliJ IDEA 2021.1.3 (Community Edition)
                      Build #IC-211.7628.21, built on June 30, 2021
                      Java version: Java JDK 17.0.1
                      JavaFX version compatible with Java JDK 17.0.1
                      Runtime version: 11.0.11+9-b1341.60 amd64
                      VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
                      Windows 10 10.0
                      GC: G1 Young Generation, G1 Old Generation
                      Memory: 768M
                      Cores: 4

                      Kotlin: 211-1.4.32-release-IJ7628.19
Date - 12/13/2022

How to run -  To run the application, run the main method.
On the initial login screen, user the credentials "test" for the username and "test" for the password.
Alternatively, use the credentials "admin" for the username and "admin" for the password.

Additional Report - The third report shows a sum of the appointments by customer ID.

MySQL Driver Connector - mysql-connector-java-8.0.25

