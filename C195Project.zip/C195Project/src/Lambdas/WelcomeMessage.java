package Lambdas;

/** Lambda to generate a welcome message in the terminal. */
public interface WelcomeMessage {
    String welcomeMessage(WelcomeMessage s);
}
